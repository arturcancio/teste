Icons made by:
 - Smashicons: https://www.flaticon.com/authors/smashicons
 - Freepik: https://www.flaticon.com/authors/Freepik

www.flaticon.com is licensed by "CC 3.0 BY": http://creativecommons.org/licenses/by/3.0/

