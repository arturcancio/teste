These icons come from:

* Table by icon 54 from the Noun Project
* vertical stacked chart by Sophia Bai from the Noun Project
* Number by Travis Avery from the Noun Project
* edit by M Yudi Maulana from the Noun Project
* items by Adrien Coquet from the Noun Project
* others by Igé Maulana from the Noun Project